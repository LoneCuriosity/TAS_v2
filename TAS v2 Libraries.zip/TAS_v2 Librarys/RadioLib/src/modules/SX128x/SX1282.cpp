#include "SX1282.h"
#if !defined(RADIOLIB_EXCLUDE_SX128X)

/// \todo implement advanced ranging
SX1282::SX1282(Module* mod) : SX1280(mod) {

}

#endif
