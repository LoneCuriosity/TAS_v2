# Wireless Programming for Moteinos

Here are sample programs to get you started with wireless programming of Moteinos.

# GUI
![GUI v1.6](https://raw.githubusercontent.com/LowPowerLab/WirelessProgramming/master/OTAGUI.png)

## The Wireless Programming GUI and python script are now in the [WirelessProgramming repository](https://github.com/LowPowerLab/WirelessProgramming)